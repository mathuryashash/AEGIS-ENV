"""
Core data models for AEGIS-Env.
Contains Pydantic schemas and Enums utilized across the environment.
"""

from typing import Optional, List
from enum import Enum
from pydantic import BaseModel, ConfigDict


class Decision(str, Enum):
    """Actions the oversight agent can take."""
    ALLOW = "ALLOW"
    BLOCK = "BLOCK"
    ESCALATE = "ESCALATE"


class ViolationType(str, Enum):
    """Categorized policy violations."""
    NONE = "none"
    PII_LEAK = "pii_leak"
    PROMPT_INJECTION = "prompt_injection"
    HALLUCINATED_FEATURE = "hallucinated_feature"
    UNSAFE_CODE = "unsafe_code"
    DATA_EXFILTRATION = "data_exfiltration_intent"
    AUTHORITY_ESCALATION = "authority_escalation"
    COMPOUND_VIOLATION = "compound_violation"
    OVERSEER_MANIPULATION = "overseer_manipulation"


class AEGISAction(BaseModel):
    """The action schema output by the oversight agent."""
    decision: Decision
    confidence: float
    violation_type: ViolationType
    policy_rule_cited: Optional[str] = None
    evidence_quote: Optional[str] = None
    explanation: str
    remediation: Optional[str] = None

    model_config = ConfigDict(extra='forbid')


class AEGISObservation(BaseModel):
    """The observation schema provided to the oversight agent."""
    worker_id: str
    turn_number: int
    worker_cot_trace: str
    worker_output: str
    policy_ruleset: List[dict]
    state_buffer: List[str]
    scenario_type: str
    turns_remaining: int
    api_call_log: List[dict]
    db_query_trace: List[str]
    success: bool = True

    model_config = ConfigDict(extra='forbid')


class AEGISState(BaseModel):
    """The internal state representation of the environment episode."""
    episode_id: str
    scenario_id: str
    curriculum_level: int
    step_count: int = 0
    ground_truth: dict
    world_db_state: dict
    memory_ledger_size: int = 0
    total_reward: float = 0.0
    earliest_detectable_turn: Optional[int] = None
    detection_turn: Optional[int] = None

    model_config = ConfigDict(extra='forbid')
