import os
import uvicorn
from fastapi import FastAPI
from .environment import AEGISEnvironment
from .models import AEGISAction

# SRV-02: Isolated OS Parameter Injection
scenario_dir = os.getenv("SCENARIO_DIR", None)
worker_mode = os.getenv("WORKER_MODE", "scripted")
memory_enabled = os.getenv("MEMORY_ENABLED", "true").lower() == "true"
seed = int(os.getenv("SEED", "42"))

# Instantiate the environment safely decoupled from request lifespan
env = AEGISEnvironment(
    scenario_dir=scenario_dir,
    worker_mode=worker_mode,
    memory_enabled=memory_enabled,
    seed=seed,
)

# SRV-01: Explicit FastAPI Endpoint Typing
app = FastAPI(
    title="AEGIS-Env Server", description="OpenEnv backend for RL model oversight."
)


@app.post("/reset")
async def reset_env():
    """Starts a new episode, generating scenario logs and clearing limits."""
    obs, info = env.reset()
    return {"observation": obs, "info": info}


@app.post("/step")
async def step_env(action: AEGISAction):
    """Calculates reward and progresses environmental state."""
    # Ensure standard model_dump compatibility with the core simulator dict structure
    obs, reward, done, info = env.step(action.model_dump())
    return {"observation": obs, "reward": reward, "done": done, "info": info}


# Provide direct launcher bound natively
def run():
    """CLI entry point for the server."""
    import uvicorn

    port = int(os.environ.get("PORT", "7860"))
    uvicorn.run("aegis_env.server:app", host="0.0.0.0", port=port)


if __name__ == "__main__":
    run()
