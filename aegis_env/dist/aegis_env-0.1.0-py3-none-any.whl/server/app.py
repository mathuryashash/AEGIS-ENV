import os
from fastapi import FastAPI
from pydantic import BaseModel

from aegis_env.environment import AEGISEnvironment
from aegis_env.models import AEGISAction


scenario_dir = os.getenv("SCENARIO_DIR", None)
worker_mode = os.getenv("WORKER_MODE", "scripted")
memory_enabled = os.getenv("MEMORY_ENABLED", "true").lower() == "true"
seed = int(os.getenv("SEED", "42"))

env = AEGISEnvironment(
    scenario_dir=scenario_dir,
    worker_mode=worker_mode,
    memory_enabled=memory_enabled,
    seed=seed,
)

app = FastAPI(title="AEGIS-Env", description="OpenEnv backend for RL model oversight.")


class StepRequest(BaseModel):
    action: AEGISAction


@app.post("/reset")
async def reset_env():
    obs, info = env.reset()
    return {"observation": obs, "info": info}


@app.post("/step")
async def step_env(request: StepRequest):
    obs, reward, done, info = env.step(request.action.model_dump())
    return {"observation": obs, "reward": float(reward), "done": done, "info": info}


def main():
    import uvicorn

    port = int(os.getenv("PORT", "7860"))
    uvicorn.run(app, host="0.0.0.0", port=port)


if __name__ == "__main__":
    main()
