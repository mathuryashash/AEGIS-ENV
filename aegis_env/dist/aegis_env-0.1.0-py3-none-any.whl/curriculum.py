import random
from typing import Dict, Any

class CurriculumScheduler:
    """CUR-01, CUR-02: Logic to derive difficulty level from the current training step."""
    
    @staticmethod
    def get_level(training_step: int) -> int:
        if training_step < 150:
            return 1
        elif training_step < 350:
            return 2
        elif training_step < 550:
            return 3
        else:
            return 4

import os
import json
from typing import Dict, Any, Optional

class ScenarioLoader:
    """SCN-10: Scenario loader mapping level to sampled scenarios."""
    def __init__(self, scenario_dir: Optional[str] = None, seed: int = 42):
        self._rng = random.Random(seed)
        self.scenarios_by_level = {}
        
        if scenario_dir and os.path.exists(scenario_dir):
            for level in [1, 2, 3, 4]:
                level_path = os.path.join(scenario_dir, f"level_{level}")
                if os.path.exists(level_path):
                    self.scenarios_by_level[level] = []
                    for fname in os.listdir(level_path):
                        if fname.endswith(".json"):
                            with open(os.path.join(level_path, fname), 'r', encoding='utf-8') as f:
                                self.scenarios_by_level[level].append(json.load(f))
        
    def sample(self, level: int) -> Dict[str, Any]:
        """Samples precisely utilizing the seeded rng context."""
        pool = self.scenarios_by_level.get(level, [])
        if not pool:
            raise ValueError(f"No scenarios found for level {level}")
        return self._rng.choice(pool)
